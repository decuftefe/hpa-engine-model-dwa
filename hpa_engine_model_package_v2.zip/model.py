import cadquery as cq

body = cq.Workplane("XY").circle(12).extrude(85)
body = body.faces(">Z").workplane().pushPoints([(-12,0),(12,0)]).hole(3.2)
nozzle = cq.Workplane("XY").workplane(offset=85).circle(2.7).extrude(21.25)
trigger = cq.Workplane("XZ").workplane(offset=-12).center(0, 5).circle(1.5).extrude(20)
poppet = cq.Workplane("XY").workplane(offset=51).circle(3).extrude(20)
chamber = cq.Workplane("XY").workplane(offset=42.5).circle(5).extrude(15)
screw = cq.Workplane("XY").workplane(offset=34).center(10, 0).circle(2).extrude(10)
reset = cq.Workplane("XY").workplane(offset=59.5).center(-8, 0).circle(1.5).extrude(8)
model = body.union(nozzle).union(trigger).union(poppet).union(chamber).union(screw).union(reset)

cq.exporters.export(model, 'hpa_engine_full_internal_model.step')

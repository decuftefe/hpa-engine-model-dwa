# HPA Engine Model v2

Ten model przedstawia kompletny mechaniczny silnik HPA do repliki airsoftowej.
Zawiera korpus, zawór, dyszę, komorę akumulacyjną, śrubę regulacyjną, popychacz spustu i kanał resetujący.
Model do edycji i symulacji w Fusion 360 / FreeCAD / SolidWorks.

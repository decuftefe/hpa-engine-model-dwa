# HPA Engine Model

Model silnika HPA z pełną geometrią wewnętrzną, przygotowany w CadQuery.
Zawiera korpus, dyszę, zawór, komorę, popychacz i inne elementy.
Gotowy do otwarcia w Fusion 360, FreeCAD lub SolidWorks.
